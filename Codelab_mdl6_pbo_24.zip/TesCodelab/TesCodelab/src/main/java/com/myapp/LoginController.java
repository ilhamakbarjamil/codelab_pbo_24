package com.myapp;

public class LoginController {
}
